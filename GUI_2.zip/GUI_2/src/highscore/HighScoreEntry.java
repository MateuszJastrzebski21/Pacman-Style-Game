package highscore;

import java.io.Serializable;

public class HighScoreEntry implements Comparable<HighScoreEntry>, Serializable {
    private static final int serialVersionUID = 1;

    private String playerName;
    private int score;

    public HighScoreEntry(String playerName, int score) {
        this.playerName = playerName;
        this.score = score;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getScore() {
        return score;
    }

    @Override
    public int compareTo(HighScoreEntry o) {
        return Integer.compare(o.score, this.score);
    }
}