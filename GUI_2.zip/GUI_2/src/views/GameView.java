package views;

import board.Board;
import board.BoardPanel;
import game.GameModel;
import movers.Controller;

import javax.swing.*;
import java.awt.*;

public class GameView {
    private JFrame gameWindow;
    private BoardPanel boardPanel;
    private static final int MIN_SIZE = 10;
    private static final int MAX_SIZE = 100;
    private int windowWidth = 700;
    private int windowHeight = 700;
    private JPanel infoPanel;
    private JLabel scoreLabel;
    private JLabel timeLabel;
    private JLabel livesLabel;
    private GameModel gameModel;

    public GameView(GameModel gameModel) {
        this.gameModel = gameModel;
        setupGameWindow();
    }

    private void setupGameWindow() {
        gameWindow = new JFrame("Pac-Man");
        gameWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gameWindow.pack();
        gameWindow.setVisible(true);
        gameWindow.setResizable(false);

        infoPanel = new JPanel();
        infoPanel.setLayout(new GridLayout(1, 3));

        scoreLabel = new JLabel("Score 0");
        timeLabel = new JLabel("Time: 0");
        livesLabel = new JLabel("Lives: 3");

        infoPanel.add(scoreLabel);
        infoPanel.add(timeLabel);
        infoPanel.add(livesLabel);

        gameWindow.add(infoPanel, BorderLayout.NORTH);
    }

    public Dimension askBoardSize() {
        int rows = getIntFromUser("Enter the number of rows (10-100: ", MIN_SIZE, MAX_SIZE);
        int columns = getIntFromUser("Enter the number of columns (10-100): ", MIN_SIZE, MAX_SIZE);

        return new Dimension(rows, columns);
    }

    private int getIntFromUser(String message, int minValue, int maxValue) {
        int value;
        boolean validInput = false;

        do {
            try {
                String input = JOptionPane.showInputDialog(message);
                value = Integer.parseInt(input);

                if (value >= minValue && value <= maxValue) {
                    validInput = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Please provide a number in range");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please provide a number");
                value = minValue - 1;
            }
        } while (!validInput);

        return value;
    }

    public void setBoardPanel(Board board) {
        boardPanel = new BoardPanel(board, windowWidth, windowHeight);
        gameWindow.add(boardPanel);
        gameWindow.pack();
    }

    public void addKeyListener(Controller controller) {
        boardPanel.addKeyListener(controller);
        boardPanel.setFocusable(true);
        boardPanel.requestFocusInWindow();
    }

    public BoardPanel getBoardPanel() {
        return boardPanel;
    }

    public void showFrame() {
        gameWindow.setVisible(true);
    }

    public void hideFrame() {
        gameWindow.setVisible(false);
    }

    public void updateScore(int score) {
        scoreLabel.setText("Score " + score);
    }

    public void updateTime(int time) {
        timeLabel.setText("Time: " + time);
    }

    public void updateLives(int lives) {
        livesLabel.setText("Lives: " + lives);
    }

    public void saveHighScore(int score) {
        String playerName = JOptionPane.showInputDialog("Game Over!" + "Your score: " + score + "Please enter your name: ");
        gameModel.saveHighScore(playerName, score);
    }

    public void setGameModel(GameModel gameModel) {
        this.gameModel = gameModel;
    }
}
