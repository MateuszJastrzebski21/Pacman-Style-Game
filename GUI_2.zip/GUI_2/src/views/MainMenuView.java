package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenuView {
    private JFrame frame;
    private JButton newGameButton;
    private JButton highScoresButton;
    private JButton exitButton;

    public MainMenuView() {
        frame = new JFrame("Pac-Man");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);

        newGameButton = new JButton("New Game");
        highScoresButton = new JButton("High Scores");
        exitButton = new JButton("Exit");

        frame.setLayout(new GridLayout(3, 1));
        frame.add(newGameButton);
        frame.add(highScoresButton);
        frame.add(exitButton);

        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        highScoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });

        frame.setVisible(true);
    }


    public void addNewGameButtonActionListener(ActionListener listener) {
        newGameButton.addActionListener(listener);
    }

    public void addHighScoresButtonActionListener(ActionListener listener) {
        highScoresButton.addActionListener(listener);
    }

    public void addExitButtonActionListener(ActionListener listener) {
        exitButton.addActionListener(listener);
    }

    public void hideFrame() {
        frame.setVisible(false);
    }

    public void showFrame() {
        frame.setVisible(true);
    }

    public void disposeFrame() {
        frame.dispose();
    }
}
