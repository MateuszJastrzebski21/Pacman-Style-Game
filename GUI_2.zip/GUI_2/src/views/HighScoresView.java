package views;

import game.GameModel;
import highscore.HighScoreEntry;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class HighScoresView {
    private JFrame highScoresWindow;
    private JPanel highScoresPanel;
    private GameModel gameModel;

    public HighScoresView(GameModel gameModel) {
        this.gameModel = gameModel;
        setupHighScoresWindow();
    }

    private void setupHighScoresWindow() {
        highScoresWindow = new JFrame("High Scores");
        highScoresWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        highScoresWindow.setLayout(new BorderLayout());
        highScoresWindow.setSize(300, 300);
        highScoresWindow.setResizable(false);

        highScoresPanel = new JPanel();
        highScoresPanel.setLayout(new BoxLayout(highScoresPanel, BoxLayout.PAGE_AXIS));

        highScoresWindow.add(highScoresPanel, BorderLayout.CENTER);
        highScoresWindow.setVisible(false);
    }


    public void showFrame() {
        if (gameModel != null) {
            updateHighScores(gameModel.loadHighScores());
        }
        highScoresWindow.setVisible(true);
    }

    public void hideFrame() {
        highScoresWindow.setVisible(false);
    }

    public void updateHighScores(List<HighScoreEntry> highScores) {
        highScoresPanel.removeAll();
        highScoresPanel.revalidate();
        highScoresPanel.repaint();

        for (HighScoreEntry entry : highScores) {
            JLabel label = new JLabel(entry.getPlayerName() + ": " + entry.getScore());
            highScoresPanel.add(label);
        }
    }

    private void displayHighScores() {
        updateHighScores(gameModel.loadHighScores());
    }
}