package board;

public enum Cell {
    PATH,
    WALL,
    PACMAN,
    BLINKY,
    PINKY,
    INKY,
    CLYDE,
    COIN,
    UPGRADE
}
