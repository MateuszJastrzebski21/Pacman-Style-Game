package board;

import javax.swing.table.AbstractTableModel;

public class BoardTableModel extends AbstractTableModel {
    private Board board;

    public BoardTableModel(Board board) {
        this.board = board;
    }

    @Override
    public int getRowCount() {
        return board.getRows();
    }

    @Override
    public int getColumnCount() {
        return board.getColumns();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return board.getCell(rowIndex, columnIndex);
    }
}
