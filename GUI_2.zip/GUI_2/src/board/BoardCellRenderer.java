package board;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.util.Map;

public class BoardCellRenderer extends JLabel implements TableCellRenderer {
    private Map<Cell, ImageIcon> cellIcons;

    public BoardCellRenderer(Map<Cell, ImageIcon> icons) {
        this.cellIcons = icons;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Cell cell = (Cell) value;

        setIcon(cellIcons.get(cell));

        if (cell == Cell.PACMAN || cell == Cell.BLINKY || cell == Cell.PINKY || cell == Cell.INKY || cell == Cell.CLYDE || cell == Cell.COIN) {
            setOpaque(true);
        } else {
            setBackground(null);
            setOpaque(cell != Cell.PATH);
        }

        return this;
    }
}
