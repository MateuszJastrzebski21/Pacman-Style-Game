package board;


import movers.Character;

public class Board {
    private int rows;
    private int columns;
    private Cell[][] board;


    private static final int MAZE_PATTERN_WIDTH = 6;
    private static final int MAZE_PATTERN_HEIGHT = 6;
    private static final String[][] MAZE_PATTERNS = {
            {
                    "WWPWWW",
                    "WWPPPP",
                    "PPPWWW",
                    "WPPPPW",
                    "WPWPPP",
                    "WPWWWW",
            },
            {
                    "PWWPWW",
                    "PPWPWP",
                    "WPPPPP",
                    "WWPWWW",
                    "PPPPPW",
                    "PWWWPP",
            },
            {
                    "WPPWWW",
                    "WWPPPW",
                    "PWPWPP",
                    "PPPWWW",
                    "WWPPPP",
                    "WWPWWW",
            },
            {
                    "WPWPWW",
                    "WPWPWW",
                    "WPWPPP",
                    "PPWPPW",
                    "WPPPWW",
                    "WWWPWP",
            }
    };

    public Board(int rows, int columns) {
        this.rows = rows;
        this.columns = columns;
        this.board = new Cell[rows][columns];

        fillBoardWithPaths();
        generateMaze();
        fillBoardWithCoins();
    }


    private void fillBoardWithPaths() {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                board[row][col] = Cell.PATH;
            }
        }
    }


    private int getRandomPatternIndex() {
        return (int) (Math.random() * MAZE_PATTERNS.length);
    }

    public void generateMaze() {
        fillLeftSideWithPatterns();
        fillMiddleGapWithRectangles();
        addCenterRectangle();
        createStraightVerticalPath();
        ensurePathAboveRectangle();
        mirrorReflection();
    }


    private void fillLeftSideWithPatterns() {
        int horizontalSkip = MAZE_PATTERN_WIDTH + 1;
        int verticalSkip = MAZE_PATTERN_HEIGHT + 1;
        for (int row = 1; row < rows - 1; row += verticalSkip) {
            for (int col = 1; col < columns - 1; col += horizontalSkip) {
                int randomPatternIndex = getRandomPatternIndex();
                String[] selectedPattern = MAZE_PATTERNS[randomPatternIndex];

                for (int patternRow = 0; patternRow < MAZE_PATTERN_HEIGHT && row + patternRow < rows - 1; patternRow++) {
                    for (int patternCol = 0; patternCol < MAZE_PATTERN_WIDTH && col + patternCol < columns / 2 - 1; patternCol++) {
                        char cellType = selectedPattern[patternRow].charAt(patternCol);

                        if (cellType == 'W') {
                            board[row + patternRow][col + patternCol] = Cell.WALL;
                        } else {
                            board[row + patternRow][col + patternCol] = Cell.PATH;
                        }
                    }
                }
            }
        }
    }

    private void fillMiddleGapWithRectangles() {
        int middleCol = columns / 2;
        int gapRectHeight = 3;
        int centerRectRow = (rows / 2) - (gapRectHeight / 2) - 1;

        for (int row = 1; row < rows - 1; row += gapRectHeight + 1) {
            for (int rectRow = 0; rectRow < gapRectHeight && row + rectRow < rows - 1; rectRow++) {
                if (columns % 2 == 0) {
                    if (row + rectRow != centerRectRow - 1) {
                        board[row + rectRow][middleCol - 1] = Cell.WALL;
                        board[row + rectRow][middleCol] = Cell.WALL;
                    }
                } else {
                    board[row + rectRow][middleCol] = Cell.WALL;
                }
            }
        }
    }

    private void addCenterRectangle() {
        int middleCol = columns / 2;
        int centerRectWidth = 4;
        int centerRectRow = (rows / 2) - 1;

        for (int col = middleCol - centerRectWidth / 2; col < middleCol + centerRectWidth / 2; col++) {
            if (col >= 0 && col < columns) {
                board[centerRectRow][col] = Cell.WALL;
            }
        }
    }

    private void createStraightVerticalPath() {
        if (columns % 2 == 0) {
            int middleCol = columns / 2;
            for (int row = 1; row < rows; row++) {
                if (row != (rows / 2) - 1) {
                    board[row][middleCol - 2] = Cell.PATH;
                    board[row][middleCol + 1] = Cell.PATH;
                }
            }
        }
    }

    private void ensurePathAboveRectangle() {
        int middleCol = columns / 2;
        int centerRectWidth = 4;
        int centerRectRow = (rows / 2) - 1;

        if (columns % 2 == 0) {
            for (int col = middleCol - centerRectWidth / 2; col < middleCol + centerRectWidth / 2; col++) {
                if (col >= 0 && col < columns) {
                    board[centerRectRow - 1][col] = Cell.PATH;
                }
            }
        } else {
            for (int col = middleCol - centerRectWidth / 2; col < middleCol + centerRectWidth / 2; col++) {
                if (col >= 0 && col < columns) {
                    board[centerRectRow - 1][col] = Cell.PATH;
                }
            }
        }
    }

    private void mirrorReflection() {
        for (int row = 1; row < rows - 1; row++) {
            for (int col = columns / 2; col < columns - 1; col++) {
                board[row][col] = board[row][columns - col - 1];
            }
        }
    }

    public void addEntity(Character entity) {
        int row = entity.getRow();
        int column = entity.getColumn();
        Cell type = entity.getType();
        if (row >= 0 && row < rows && column >= 0 && column < columns) {
            board[row][column] = type;
        }
    }

    private void fillBoardWithCoins() {
        for (int row = 1; row < rows - 1; row++) {
            for (int col = 1; col < columns - 1; col++) {
                    if (board[row][col] == Cell.PATH) {
                        board[row][col] = Cell.COIN;
                }
            }
        }
    }

    public int getRows() {
        return rows;
    }

    public int getColumns() {
        return columns;
    }

    public Cell getCell(int row, int column) {
        return board[row][column];
    }
}


