package board;

import javax.swing.*;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class BoardPanel extends JPanel {
    private Board board;
    private JTable table;
    private BoardTableModel tableModel;
    private Map<Cell, ImageIcon> icons;
    private int windowWidth;
    private int windowHeight;

    public BoardPanel(Board board, int windowWidth, int windowHeight) {
        this.board = board;
        this.windowWidth = windowWidth;
        this.windowHeight = windowHeight;
        loadIcons();
        initializeTable();
    }

    private void initializeTable() {
        int cellSize = Math.min(windowWidth / board.getColumns(), windowHeight / board.getRows());
        int totalWidth = board.getColumns() * cellSize;
        int totalHeight = board.getRows() * cellSize;

        tableModel = new BoardTableModel(board);
        table = new JTable(tableModel);
        table.setBackground(Color.BLACK);
        table.setRowHeight(cellSize);
        table.setShowGrid(false);
        table.setTableHeader(null);
        table.setIntercellSpacing(new Dimension(0,0));
        table.setDefaultRenderer(Object.class, new BoardCellRenderer(icons));
        table.setOpaque(false);
        setLayout(new BorderLayout());
        add(table, BorderLayout.CENTER);

        TableColumnModel columnModel = table.getColumnModel();
        for (int i = 0; i < columnModel.getColumnCount(); i++) {
            TableColumn column = columnModel.getColumn(i);
            column.setPreferredWidth(cellSize);
        }

        setPreferredSize(new Dimension(totalWidth, totalHeight));
    }


    private void loadIcons() {
        int cellSize = Math.min(windowWidth / board.getColumns(), windowHeight / board.getRows());
        icons = new HashMap<>();

        icons.put(Cell.PACMAN, resizeIcon(new ImageIcon(getClass().getResource("/images/PacMan.png")), cellSize));
        icons.put(Cell.BLINKY, resizeIcon(new ImageIcon(getClass().getResource("/images/Blinky.png")), cellSize));
        icons.put(Cell.PINKY, resizeIcon(new ImageIcon(getClass().getResource("/images/Pinky.png")), cellSize));
        icons.put(Cell.INKY, resizeIcon(new ImageIcon(getClass().getResource("/images/Inky.png")), cellSize));
        icons.put(Cell.CLYDE, resizeIcon(new ImageIcon(getClass().getResource("/images/Clyde.png")), cellSize));
        icons.put(Cell.WALL, resizeIcon(new ImageIcon(getClass().getResource("/images/Wall.png")), cellSize));
        icons.put(Cell.PATH, resizeIcon(new ImageIcon(getClass().getResource("/images/Path.png")), cellSize));
        icons.put(Cell.COIN, resizeIcon(new ImageIcon(getClass().getResource("/images/Coin.png")), cellSize));
    }

    private ImageIcon resizeIcon(ImageIcon icon, int size) {
        Image img = icon.getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }

    public void updateBoard(Board board) {
        this.board = board;
        repaint();
    }
}
