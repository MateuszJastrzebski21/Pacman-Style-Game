package timer;

import game.GameController;

public class TimerThread extends Thread{
    private final GameController gameController;
    private final long intervalMilliseconds;
    private volatile boolean stop;

    public TimerThread(GameController gameController, long intervalMilliseconds) {
        this.gameController = gameController;
        this.intervalMilliseconds = intervalMilliseconds;
        this.stop = false;
    }

    @Override
    public void run() {
        while (!stop) {
            try {
                Thread.sleep(intervalMilliseconds);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            gameController.updateTimer();
        }
    }
    public void stopTimer() {
        this.stop = true;
    }
}
