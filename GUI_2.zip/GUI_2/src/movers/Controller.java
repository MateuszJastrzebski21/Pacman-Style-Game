package movers;

import game.GameController;
import game.GameModel;
import movers.Direction;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Controller extends KeyAdapter {
    private final GameModel gameModel;
    private final GameController gameController;

    public Controller(GameModel gameModel, GameController gameController) {
        this.gameModel = gameModel;
        this.gameController = gameController;
    }

    @Override
    public void keyPressed(KeyEvent e) {

        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP:
                gameModel.setDesiredDirection(Direction.UP);
                break;
            case KeyEvent.VK_DOWN:
                gameModel.setDesiredDirection(Direction.DOWN);
                break;
            case KeyEvent.VK_LEFT:
                gameModel.setDesiredDirection(Direction.LEFT);
                break;
            case KeyEvent.VK_RIGHT:
                gameModel.setDesiredDirection(Direction.RIGHT);
                break;
        }

        gameModel.movePacMan();

        if(e.isControlDown() && e.isShiftDown() && e.getKeyCode() == KeyEvent.VK_Q) {
            gameController.handleShortcut(e);
        }
    }

}
