package movers;

import game.GameModel;

public class GhostMover implements Runnable{
    private final GameModel gameModel;
    private final int moveDelay;
    private Character ghost;

    public GhostMover(GameModel gameModel, int moveDelay, Character ghost) {
        this.gameModel = gameModel;
        this.moveDelay = moveDelay;
        this.ghost = ghost;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                Direction newDirection = randomDirection();
                while (!gameModel.canMoveInDirection(ghost, newDirection)) {
                    newDirection = randomDirection();
                }

                gameModel.moveGhost(ghost, newDirection);
                Thread.sleep(moveDelay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private Direction randomDirection() {
        return Direction.values()[(int) (Math.random() * Direction.values().length)];
    }
}
