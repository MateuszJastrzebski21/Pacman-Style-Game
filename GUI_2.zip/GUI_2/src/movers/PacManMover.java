package movers;

import game.GameModel;

public class PacManMover implements Runnable {
    private final GameModel gameModel;
    private final int moveDelay;

    public PacManMover(GameModel gameModel, int moveDelay) {
        this.gameModel = gameModel;
        this.moveDelay = moveDelay;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                gameModel.movePacMan();
                Thread.sleep(moveDelay);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
