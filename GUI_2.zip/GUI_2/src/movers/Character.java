package movers;

import board.Cell;

public class Character {
    private Cell type;
    private int row;
    private int column;

    public Character(Cell type, int row, int column) {
        this.type = type;
        this.row = row;
        this.column = column;
    }

    public Cell getType() {
        return type;
    }

    public int getRow() {
        return row;
    }

    public int getColumn() {
        return column;
    }

    public void updatePosition(int newRow, int newColumn) {
        this.row = newRow;
        this.column = newColumn;
    }
}
