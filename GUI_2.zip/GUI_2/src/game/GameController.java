package game;

import board.Board;
import movers.Character;
import movers.Controller;
import movers.GhostMover;
import movers.PacManMover;
import timer.TimerThread;
import views.GameView;
import views.HighScoresView;
import views.MainMenuView;

import java.awt.*;
import java.awt.event.KeyEvent;


public class GameController {
    private Board board;
    private GameView gameView;
    private GameModel gameModel;
    private Controller controller;
    private MainMenuView mainMenuView;
    private TimerThread timerThread;
    private int timeElapsed;
    private HighScoresView highScoresView;

    public GameController(MainMenuView mainMenuView) {
        this.mainMenuView = mainMenuView;
        setupMainMenu();
    }

    private void setupMainMenu() {
        mainMenuView.addNewGameButtonActionListener(e -> startNewGame());
        mainMenuView.addHighScoresButtonActionListener(e -> displayHighScores());
        mainMenuView.addExitButtonActionListener(e -> exitGame());
    }

    public void displayHighScores() {
        highScoresView = new HighScoresView(gameModel);
        highScoresView.showFrame();
    }

    private void startNewGame() {
        setupGame();
        mainMenuView.hideFrame();
        gameView.showFrame();
    }

    private void exitGame() {
        mainMenuView.disposeFrame();
    }

    private void setupGame() {
        gameView = new GameView(gameModel);
        Dimension boardSize = gameView.askBoardSize();
        board = new Board(boardSize.width, boardSize.height);
        gameView.setBoardPanel(board);

        gameModel = new GameModel(board, gameView.getBoardPanel(), gameView, this, mainMenuView);
        gameModel.setController(this);

        controller = new Controller(gameModel, this);
        gameView.addKeyListener(controller);

        PacManMover pacManMover = new PacManMover(gameModel, 200);
        Thread pacManMoverThread = new Thread(pacManMover);
        pacManMoverThread.start();

        for (Character ghost : gameModel.getGhosts()) {
            GhostMover ghostMover = new GhostMover(gameModel, 300, ghost);
            Thread ghostMoverThread = new Thread(ghostMover);
            ghostMoverThread.start();
        }

        timeElapsed = 0;
        timerThread = new TimerThread(this, 1000);
        timerThread.start();
    }

    public void handleShortcut(KeyEvent e) {
        if (e.isControlDown() && e.isShiftDown() && e.getKeyCode() == KeyEvent.VK_Q) {
            gameView.hideFrame();
            mainMenuView.showFrame();
        }
    }

    public void updateTimer() {
        timeElapsed++;
        gameView.updateTime(timeElapsed);
    }
}