package game;

import board.*;
import highscore.HighScoreEntry;
import movers.Character;
import movers.Direction;
import views.GameView;
import views.MainMenuView;

import java.awt.*;
import java.util.List;
import java.io.*;
import java.util.*;


public class GameModel {
    private Direction currentDirection;
    private Direction desiredDirection;
    private Board board;
    private BoardPanel boardPanel;
    private Character pacMan;
    private Map<Cell, Character> ghosts;
    private int score;
    private int lives;
    private int pacManStartRow;
    private int pacManStartColumn;
    private GameView gameView;
    private Map<Cell, Point> ghostStartPositions;
    private GameController controller;
    private static final String HIGH_SCORES_FILE = "high_scores.ser";
    private MainMenuView mainMenuView;


    public GameModel(Board board, BoardPanel boardPanel, GameView gameView, GameController controller, MainMenuView mainMenuView) {
        this.board = board;
        this.boardPanel = boardPanel;
        this.controller = controller;
        this.mainMenuView = mainMenuView;
        currentDirection = Direction.NONE;
        desiredDirection = Direction.NONE;


        pacManStartRow = 0;
        pacManStartColumn = board.getColumns() / 2;
        pacMan = new Character(Cell.PACMAN, pacManStartRow, pacManStartColumn);
        board.addEntity(pacMan);

        ghosts = new HashMap<>();

        int ghostRow = board.getRows() / 2 - 2;
        int ghostColumn = board.getColumns() / 2 - 2;

        ghosts.put(Cell.BLINKY, new Character(Cell.BLINKY, ghostRow, ghostColumn));
        ghosts.put(Cell.PINKY, new Character(Cell.PINKY, ghostRow, ghostColumn + 1));

        if (board.getColumns() % 2 == 1) {
            ghostColumn++;
        }


        ghosts.put(Cell.INKY, new Character(Cell.INKY, ghostRow, ghostColumn + 2));
        ghosts.put(Cell.CLYDE, new Character(Cell.CLYDE, ghostRow, ghostColumn + 3));

        for (Character ghost : ghosts.values()) {
            board.addEntity(ghost);
        }

        ghostColumn = board.getColumns() / 2 - 2;
        ghostStartPositions = new HashMap<>();
        ghostStartPositions.put(Cell.BLINKY, new Point(ghostRow, ghostColumn));
        ghostStartPositions.put(Cell.PINKY, new Point(ghostRow, ghostColumn + 1));

        if (board.getColumns() % 2 == 1) {
            ghostColumn++;
        }

        ghostStartPositions.put(Cell.INKY, new Point(ghostRow, ghostColumn + 2));
        ghostStartPositions.put(Cell.CLYDE, new Point(ghostRow, ghostColumn + 3));


        this.score = 0;
        this.lives = 3;

        this.gameView = gameView;
        this.gameView.setGameModel(this);
    }

    public void setDesiredDirection(Direction desiredDirection) {
        this.desiredDirection = desiredDirection;
    }

    public void movePacMan() {
        if (desiredDirection != Direction.NONE && canMoveInDirection(pacMan, desiredDirection)) {
            currentDirection = desiredDirection;
        }

        if (canMoveInDirection(pacMan, currentDirection)) {
            int newRow = pacMan.getRow() + currentDirection.getRowChange();
            int newColumn = pacMan.getColumn() + currentDirection.getColumnChange();

            if (board.getCell(newRow, newColumn) == Cell.COIN) {
                collectCoin();
            }

            board.addEntity(new Character(Cell.PATH, pacMan.getRow(), pacMan.getColumn()));
            pacMan.updatePosition(newRow, newColumn);
            board.addEntity(pacMan);

            handleCollision();

            boardPanel.updateBoard(board);
        }
    }

    public void moveGhost(Character ghost, Direction direction) {
        if (canMoveInDirection(ghost, direction)) {
            int newRow = ghost.getRow() + direction.getRowChange();
            int newColumn = ghost.getColumn() + direction.getColumnChange();

            if (isPacMan(newRow, newColumn)) {
                lives--;
                if (lives <= 0) {
                    gameOver();
                } else {
                    resetPositions();
                }
            } else {
                Cell targetCell = board.getCell(newRow, newColumn);
                if (targetCell == Cell.COIN) {
                    score++;
                }

                board.addEntity(new Character(Cell.PATH, ghost.getRow(), ghost.getColumn()));
                ghost.updatePosition(newRow, newColumn);
                board.addEntity(ghost);
                boardPanel.updateBoard(board);
            }
        }
        updateLivesDisplay(gameView);
    }

    private void handleCollision() {
        for (Character ghost : ghosts.values()) {
            if (isPacMan(ghost.getRow(), ghost.getColumn())) {
                lives--;
                if (lives <= 0) {
                    gameOver();
                } else {
                    resetPositions();
                }
                break;
            }
        }
        updateLivesDisplay(gameView);
    }

    public boolean canMoveInDirection(Character character, Direction direction) {
        int newRow = character.getRow() + direction.getRowChange();
        int newColumn = character.getColumn() + direction.getColumnChange();

        if (newRow >= 0 && newRow < board.getRows() && newColumn >= 0 && newColumn < board.getColumns()) {
            Cell cell = board.getCell(newRow, newColumn);
            return cell != Cell.WALL;
        }

        return false;
    }

    private boolean isPacMan(int row, int column) {
        return pacMan.getRow() == row && pacMan.getColumn() == column;
    }

    public Collection<Character> getGhosts() {
        return ghosts.values();
    }

    private void resetPositions() {
        pacMan.updatePosition(pacManStartRow, pacManStartColumn);
        board.addEntity(pacMan);

        for (Character ghost : ghosts.values()) {
            Point startPoint = ghostStartPositions.get(ghost.getType());
            int newRow = (int) startPoint.getX();
            int newColumn = (int) startPoint.getY();

            board.addEntity(new Character(Cell.PATH, ghost.getRow(), ghost.getColumn()));
            ghost.updatePosition(newRow, newColumn);
            board.addEntity(ghost);
        }
        boardPanel.updateBoard(board);
    }

    public void gameOver() {

        score = 0;
        lives = 3;
        resetPositions();

        gameView.hideFrame();

        mainMenuView.showFrame();
    }

    public void saveHighScore(String playerName, int score) {
        List<HighScoreEntry> highScores = loadHighScores();
        highScores.add(new HighScoreEntry(playerName, score));
        Collections.sort(highScores, (entry1, entry2) -> entry2.getScore() - entry1.getScore());


        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(HIGH_SCORES_FILE))) {
            oos.writeObject(highScores);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<HighScoreEntry> loadHighScores() {
        List<HighScoreEntry> highScores;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(HIGH_SCORES_FILE))){
            highScores = (List<HighScoreEntry>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            highScores = new ArrayList<>();
        }
        return highScores;
    }

    public void collectCoin() {
        score++;
        gameView.updateScore(score);
    }

    public void updateLivesDisplay(GameView gameView) {
        gameView.updateLives(lives);
    }

    public void setController(GameController controller) {
        this.controller = controller;
    }

}